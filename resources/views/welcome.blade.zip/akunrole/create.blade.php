@extends('layouts.app') 

@section('title', 'Tambah Akun Baru')

@section('content')

<style>
    @keyframes fadeInUp {
        from { opacity: 0; transform: translate3d(0, 20px, 0); }
        to { opacity: 1; transform: translate3d(0, 0, 0); }
    }
    .animate-fade-in-up {
        animation-name: fadeInUp;
        animation-duration: 0.5s;
        animation-fill-mode: forwards;
    }
</style>

<div class="max-w-4xl mx-auto py-6 animate-fade-in-up">

    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
        <div>
            <h2 class="text-2xl font-bold text-gray-800 flex items-center">
                <span class="bg-indigo-100 text-indigo-600 p-2 rounded-lg mr-3 shadow-sm">
                    <i class="fas fa-user-plus"></i>
                </span>
                Tambah Akun Baru
            </h2>
            <p class="text-gray-500 text-sm mt-1 ml-1">Buat akun baru untuk akses sistem (Admin/Gudang).</p>
        </div>
        
        <a href="{{ route('akunrole.index') }}" class="bg-white text-gray-600 border border-gray-300 hover:bg-gray-50 py-2 px-4 rounded-lg font-medium shadow-sm transition-all flex items-center">
            <i class="fas fa-arrow-left mr-2"></i> Kembali
        </a>
    </div>

    <form action="{{ route('akunrole.store') }}" method="POST" class="bg-white shadow-xl rounded-xl p-8 border border-gray-100">
        @csrf

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div class="md:col-span-2">
                <label for="name" class="block text-sm font-semibold text-gray-700 mb-1">Nama Lengkap</label>
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400"><i class="fas fa-user"></i></span>
                    <input type="text" name="name" id="name" value="{{ old('name') }}" required 
                           class="w-full pl-10 border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="Masukkan nama lengkap...">
                </div>
            </div>

            <div>
                <label for="email" class="block text-sm font-semibold text-gray-700 mb-1">Email</label>
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400"><i class="fas fa-envelope"></i></span>
                    <input type="email" name="email" id="email" value="{{ old('email') }}" required 
                           class="w-full pl-10 border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="email@contoh.com">
                </div>
            </div>

            {{-- Role CEO dihapus dari pilihan --}}
            <div>
                <label for="role" class="block text-sm font-semibold text-gray-700 mb-1">Pilih Role</label>
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400"><i class="fas fa-user-shield"></i></span>
                    <select name="role" id="role" required class="w-full pl-10 border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-indigo-500 outline-none appearance-none">
                        <option value="admin" {{ old('role') == 'admin' ? 'selected' : '' }}>ADMIN</option>
                        <option value="gudang" {{ old('role') == 'gudang' ? 'selected' : '' }}>GUDANG</option>
                    </select>
                </div>
            </div>

            <div>
                <label for="password" class="block text-sm font-semibold text-gray-700 mb-1">Password</label>
                <input type="password" name="password" id="password" required class="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-indigo-500 outline-none">
            </div>

            <div>
                <label for="password_confirmation" class="block text-sm font-semibold text-gray-700 mb-1">Konfirmasi Password</label>
                <input type="password" name="password_confirmation" id="password_confirmation" required class="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-indigo-500 outline-none">
            </div>
        </div>

        <div class="mt-8 flex justify-end gap-3 pt-6 border-t border-gray-100">
            <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-2.5 rounded-lg font-bold shadow-md active:scale-95 transition-all">
                <i class="fas fa-save mr-2"></i> Simpan Akun
            </button>
        </div>
    </form>
</div>
@endsection