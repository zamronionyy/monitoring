@extends('layouts.app') 

@section('title', 'Edit Akun Pengguna')

@section('content')

<div class="max-w-4xl mx-auto py-6 animate-fade-in-up">
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
        <h2 class="text-2xl font-bold text-gray-800">Edit Akun: {{ $user->name }}</h2>
        <a href="{{ route('akunrole.index') }}" class="bg-white text-gray-600 border border-gray-300 py-2 px-4 rounded-lg font-medium shadow-sm transition-all">
            <i class="fas fa-arrow-left mr-2"></i> Kembali
        </a>
    </div>

    <form action="{{ route('akunrole.update', $user->id) }}" method="POST" class="bg-white shadow-xl rounded-xl p-8 border border-gray-100">
        @csrf
        @method('PUT')

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div class="md:col-span-2">
                <label for="name" class="block text-sm font-semibold text-gray-700 mb-1">Nama Lengkap</label>
                <input type="text" name="name" id="name" value="{{ old('name', $user->name) }}" required class="w-full border border-gray-300 rounded-lg p-2.5">
            </div>

            <div>
                <label class="block text-sm font-semibold text-gray-400 mb-1">Email (Readonly)</label>
                <input type="email" value="{{ $user->email }}" disabled class="w-full border border-gray-200 bg-gray-50 rounded-lg p-2.5 text-gray-400">
            </div>

            <div>
                <label for="role" class="block text-sm font-semibold text-gray-700 mb-1">Role / Hak Akses</label>
                <select name="role" id="role" required class="w-full border border-gray-300 rounded-lg p-2.5 appearance-none">
                    {{-- CEO tidak bisa dipilih di sini --}}
                    <option value="admin" {{ old('role', $user->role) == 'admin' ? 'selected' : '' }}>ADMIN</option>
                    <option value="gudang" {{ old('role', $user->role) == 'gudang' ? 'selected' : '' }}>GUDANG</option>
                    @if($user->role == 'ceo')
                        <option value="ceo" selected>CEO (Role Saat Ini)</option>
                    @endif
                </select>
            </div>
        </div>

        <div class="mt-8 flex justify-end gap-3 pt-6 border-t border-gray-100">
            <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-2.5 rounded-lg font-bold shadow-md active:scale-95 transition-all">
                <i class="fas fa-save mr-2"></i> Simpan Perubahan
            </button>
        </div>
    </form>
</div>
@endsection